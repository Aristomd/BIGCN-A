import tensorflow as tf
from include.Config import Config
from include.Model import build, training
from include.Test import *
from include.Load import *
import json
KG1 = loadfile(Config.kg1, 3) #三元组列表
KG2 = loadfile(Config.kg2, 3)
KG=KG1+KG2
dic={}
for tri in KG:
    if tri[0] not in dic:
        dic[tri[0]]=[]
        dic[tri[0]].append(tri[2])
    else:
        dic[tri[0]].append(tri[2])
    if tri[2] not in dic:
        dic[tri[2]] = []
        dic[tri[2]].append(tri[0])
    else:
        dic[tri[2]].append(tri[0])
items=json.dumps(dic)
with open('graph_dic.txt','w',encoding='utf8') as f:
    f.write(items)
