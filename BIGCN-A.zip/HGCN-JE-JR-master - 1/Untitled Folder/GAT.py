import tensorflow as tf
conv1d = tf.layers.conv1d

def attn_head(seq, out_sz, bias_mat, activation, in_drop=0.0, coef_drop=0.0, residual=False):
    with tf.name_scope('my_attn'):
        if in_drop != 0.0:
            #防止过拟合，保留seq中1.0 - in_drop个数，保留的数并变为1/1.0 - in_drop
            seq = tf.nn.dropout(seq, 1.0 - in_drop)
        #将原始节点特征 seq 进行变换得到了 seq_fts。这里，作者使用卷积核大小为 1 的 1D 卷积模拟投影变换，
        # 投影变换后的维度为 out_sz。注意，这里投影矩阵 W是所有节点共享，所以 1D 卷积中的多个卷积核也是共享的。
        #seq_fts 的大小为 [num_graph, num_node, out_sz]
        seq_fts = tf.layers.conv1d(seq, out_sz, 1, use_bias=False)

        # simplest self-attention possible
        # f_1 和 f_2 维度均为 [num_graph, num_node, 1]
        f_1 = tf.layers.conv1d(seq_fts, 1, 1)  #节点投影
        f_2 = tf.layers.conv1d(seq_fts, 1, 1)  #邻居投影

        #将 f_2 转置之后与 f_1 叠加，通过广播得到的大小为 [num_graph, num_node, num_node] 的 logits
        logits = f_1 + tf.transpose(f_2, [0, 2, 1])#注意力矩阵
        #+biase_mat是为了对非邻居节点mask,归一化的注意力矩阵
        #邻接矩阵的作用，把和中心节点没有链接的注意力因子mask掉
        coefs = tf.nn.softmax(tf.nn.leaky_relu(logits) + bias_mat)

        if coef_drop != 0.0:
            coefs = tf.nn.dropout(coefs, 1.0 - coef_drop)
        if in_drop != 0.0:
            seq_fts = tf.nn.dropout(seq_fts, 1.0 - in_drop)
         #将 mask 之后的注意力矩阵 coefs 与变换后的特征矩阵 seq_fts 相乘，
         # 即可得到更新后的节点表示 vals。
        vals = tf.matmul(coefs, seq_fts)
        # ret = tf.contrib.layers.bias_add(vals)
        #
        # # residual connection
        # if residual:
        #     if seq.shape[-1] != ret.shape[-1]:
        #         ret = ret + conv1d(seq, ret.shape[-1], 1) # activation
        #     else:
        #         ret = ret + seq
        #
        # return activation(ret)  # activation
        return vals
