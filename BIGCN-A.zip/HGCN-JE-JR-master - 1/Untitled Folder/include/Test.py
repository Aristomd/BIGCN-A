import numpy as np
import scipy


def get_hits(vec, test_pair, top_k=(1, 10, 50, 100)):
    Lvec = np.array([vec[e1] for e1, e2 in test_pair])
    Rvec = np.array([vec[e2] for e1, e2 in test_pair])
    sim1 = scipy.spatial.distance.cdist(Lvec, Rvec, metric='cityblock')
    sim2 = scipy.spatial.distance.cdist(Lvec, Rvec, metric='cityblock')#曼哈顿距离，L1范数
    top_lr = [0] * len(top_k)#生成长度为4,lr左右
    rank1 = sim1[:,:].argsort().argsort()
    rank2 = sim2[:,:].argsort().argsort()
    sim = rank1+rank2.T

    for i in range(Lvec.shape[0]): #实e1的数量，测试集一种语言数量
        rank = sim[i, :].argsort() #从小到大排列的索引
        rank_index = np.where(rank == i)[0][0]
        for j in range(len(top_k)):
            if rank_index < top_k[j]:
                top_lr[j] += 1
    top_rl = [0] * len(top_k)#rl右左
    for i in range(Rvec.shape[0]):
        rank = sim[:, i].argsort()
        rank_index = np.where(rank == i)[0][0]
        for j in range(len(top_k)):
            if rank_index < top_k[j]:
                top_rl[j] += 1
    print('Entity:')
    print('For each left:')
    for i in range(len(top_lr)):
        print('Hits@%d: %.2f%%' % (top_k[i], top_lr[i] / len(test_pair) * 100))
    print('For each right:')
    for i in range(len(top_rl)):
        print('Hits@%d: %.2f%%' % (top_k[i], top_rl[i] / len(test_pair) * 100))

        
def detect_coinc(test_pair, head, tail, ILL):
    r2e = {}
    for ill in test_pair:
        if ill[0] not in r2e:
            r2e[ill[0]] = head[ill[0]] | tail[ill[0]]  #字典关系：关系对应的头实体+尾实体的集合
        if ill[1] not in r2e:
            r2e[ill[1]] = head[ill[1]] | tail[ill[1]]

    rpairs = {}
    test_pair = np.array(test_pair)
    left = test_pair[:, 0]
    right = test_pair[:, 1]
    for i in left:
        for j in right:
            count = 0 #count表示什么的计数
            for e_1, e_2 in ILL: #e1，e2是唯一的
                if e_1 in r2e[i] and e_2 in r2e[j]: #两个关系有可能相等
                    count = count + 1
            rpairs[(i, j)] = count / (len(r2e[i]) + len(r2e[j])) #对应的公式7中的分式

    coinc = []
    for row in left:
        list = []
        for col in right:
            list.append(rpairs[(row, col)]) #list对应的是值，源关系中的一个，对应目标关系的全部值
        coinc.append(list)

    coinc = np.array(coinc)
    return coinc  #关系存在相关性的方阵，，对应于公式7beida之后的部分#第二遍理解感觉是关系相似性矩阵，这个矩阵中的关系仅仅是关系的对齐关系种子中的关系


def get_hits_rel(vec, test_pair, coinc, top_k=(1, 10, 50, 100)):
    Lvec = np.array([vec[e1] for e1, e2 in test_pair])#id相当于是索引
    Rvec = np.array([vec[e2] for e1, e2 in test_pair])
    sim = scipy.spatial.distance.cdist(Lvec, Rvec, metric='cityblock')#L，R相似度矩阵
    sim = sim - 20 * coinc #对应的是公式7
    top_lr = [0] * len(top_k)
    for i in range(Lvec.shape[0]):
        rank = sim[i, :].argsort()
        rank_index = np.where(rank == i)[0][0]
        for j in range(len(top_k)):
            if rank_index < top_k[j]:
                top_lr[j] += 1
    top_rl = [0] * len(top_k)
    for i in range(Rvec.shape[0]):
        rank = sim[:, i].argsort()
        rank_index = np.where(rank == i)[0][0]
        for j in range(len(top_k)):
            if rank_index < top_k[j]:
                top_rl[j] += 1
    print('Relation:')
    print('For each left:')
    for i in range(len(top_lr)):
        print('Hits@%d: %.2f%%' % (top_k[i], top_lr[i] / len(test_pair) * 100))
    print('For each right:')
    for i in range(len(top_rl)):
        print('Hits@%d: %.2f%%' % (top_k[i], top_rl[i] / len(test_pair) * 100))
