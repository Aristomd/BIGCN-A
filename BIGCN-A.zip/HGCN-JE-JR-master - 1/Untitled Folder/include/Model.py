import math
from .Init import *
from include.Test import *
import scipy
import json
import scipy.sparse as sp
conv1d = tf.layers.conv1d

def adj_to_bias(adj, sizes, nhood=1):
    nb_graphs = adj.shape[0]
    mt = np.empty(adj.shape)
    for g in range(nb_graphs):
        mt[g] = np.eye(adj.shape[1])
        for _ in range(nhood):
            mt[g] = np.matmul(mt[g], (adj[g] + np.eye(adj.shape[1])))
        for i in range(sizes[g]):
            for j in range(sizes[g]):
                if mt[g][i][j] > 0.0:
                    mt[g][i][j] = 1.0
    return -1e9 * (1.0 - mt)

def attn_head(seq, out_sz, bias_mat, activation, in_drop=0.0, coef_drop=0.0):
    with tf.name_scope('my_attn'):
        if in_drop != 0.0:
            #防止过拟合，保留seq中1.0 - in_drop个数，保留的数并变为1/1.0 - in_drop
            seq = tf.nn.dropout(seq, 1.0 - in_drop)
        #将原始节点特征 seq 进行变换得到了 seq_fts。这里，作者使用卷积核大小为 1 的 1D 卷积模拟投影变换，
        # 投影变换后的维度为 out_sz。注意，这里投影矩阵 W是所有节点共享，所以 1D 卷积中的多个卷积核也是共享的。
        #seq_fts 的大小为 [num_graph, num_node, out_sz]
        seq_fts = tf.layers.conv1d(seq, out_sz, 1, use_bias=False)

        # simplest self-attention possible
        # f_1 和 f_2 维度均为 [num_graph, num_node, 1]
        f_1 = tf.layers.conv1d(seq_fts, 1, 1)  #节点投影
        f_2 = tf.layers.conv1d(seq_fts, 1, 1)  #邻居投影

        #将 f_2 转置之后与 f_1 叠加，通过广播得到的大小为 [num_graph, num_node, num_node] 的 logits
        logits = f_1 + tf.transpose(f_2, [0, 2, 1])#注意力矩阵
        #+biase_mat是为了对非邻居节点mask,归一化的注意力矩阵
        #邻接矩阵的作用，把和中心节点没有链接的注意力因子mask掉
        coefs = tf.nn.softmax(tf.nn.leaky_relu(logits) + bias_mat)

        if coef_drop != 0.0:
            coefs = tf.nn.dropout(coefs, 1.0 - coef_drop)
        if in_drop != 0.0:
            seq_fts = tf.nn.dropout(seq_fts, 1.0 - in_drop)
         #将 mask 之后的注意力矩阵 coefs 与变换后的特征矩阵 seq_fts 相乘，
         # 即可得到更新后的节点表示 vals。
        vals = tf.matmul(coefs, seq_fts)
        # ret = tf.contrib.layers.bias_add(vals)
        #
        # # residual connection
        # if residual:
        #     if seq.shape[-1] != ret.shape[-1]:
        #         ret = ret + conv1d(seq, ret.shape[-1], 1) # activation
        #     else:
        #         ret = ret + seq
        #
        # return activation(ret)  # activation
        return vals




def rfunc(KG, e): #可能对应于公式7
    head = {} #字典，关系：头实体
    tail = {}
    cnt = {} #是一个关系字典，关系：关系出现的次数
    for tri in KG:
        if tri[1] not in cnt:
            cnt[tri[1]] = 1
            head[tri[1]] = set([tri[0]])
            tail[tri[1]] = set([tri[2]])
        else:
            cnt[tri[1]] += 1
            head[tri[1]].add(tri[0])
            tail[tri[1]].add(tri[2])
    r_num = len(head) #关系的数目
    head_r = np.zeros((e, r_num)) #关系实体矩阵，相关的关系实体为1，不相关的关系实体为0
    tail_r = np.zeros((e, r_num))
    for tri in KG:
        head_r[tri[0]][tri[1]] = 1
        tail_r[tri[2]][tri[1]] = 1

    return head, tail, head_r, tail_r


def get_mat(e, KG): #构建邻接矩阵A
    du = [1] * e  #长度为e，元素为1的列表，du就是度的意思
    for tri in KG:
        if tri[0] != tri[2]:  #如果相等就是自连接
            du[tri[0]] += 1
            du[tri[2]] += 1
    M = {}
    for tri in KG:
        if tri[0] == tri[2]:
            continue
        if (tri[0], tri[2]) not in M:
            M[(tri[0], tri[2])] = 1
        else:
            pass
        if (tri[2], tri[0]) not in M:
            M[(tri[2], tri[0])] = 1 #头尾实体进行区分，头尾实体的字典
        else:
            pass

    for i in range(e):
        M[(i, i)] = 1  #相当于自连接都为1
    return M, du


# get a sparse tensor based on relational triples
def get_sparse_tensor(e, KG):  #这个稀疏矩阵就应该是邻接矩阵A+I
    print('getting a sparse tensor...')
    M, du = get_mat(e, KG) #头尾实体，尾头元组，自连接元组的字典   每一个实体的度
    ind1 = []
    ind2 = []
    val = []
    for fir, sec in M:  #去元组里的元素
        ind1.append(fir)
        ind2.append(sec)
        val.append(M[(fir, sec)]) #根据实体的度度邻接矩阵进行了操作，可能是相当于D
    M = sp.coo_matrix((val, (ind1,ind2)), shape=(e, e))
    
    return M  #稀疏矩阵只在有链接的地方不为0，M应该是邻接矩阵


def add_diag_layer(inlayer, dimension, M, act_func, dropout=0.0, init=ones):
    inlayer = tf.nn.dropout(inlayer, 1 - dropout) #使输入tensor中某些元素变为0，其它没变0的元素变为原来的1/keep_prob大小！
    print('adding a diag layer...')
    w0 = init([1, dimension]) #可能是初始化一个w0
    tosum = tf.sparse_tensor_dense_matmul(M, tf.multiply(inlayer, w0)) #稀疏矩阵乘以稠密矩阵multiply(element-wise)
    if act_func is None:
        return tosum
    else:
        return act_func(tosum)


def add_full_layer(inlayer, dimension_in, dimension_out, M, act_func, dropout=0.0, init=glorot):
    inlayer = tf.nn.dropout(inlayer, 1 - dropout)
    print('adding a full layer...')
    w0 = init([dimension_in, dimension_out])
    tosum = tf.sparse_tensor_dense_matmul(M, tf.matmul(inlayer, w0))#element-wise product可以广播
    if act_func is None:
        return tosum
    else:
        return act_func(tosum)


def highway(layer1,layer2,dimension):
    kernel_gate = glorot([dimension,dimension]) #300*300产生一个均匀分布w 一种初始化方式
    bias_gate = zeros([dimension])
    transform_gate = tf.matmul(layer1, kernel_gate) + bias_gate #矩阵加法也可以广播
    transform_gate = tf.nn.sigmoid(transform_gate)# 对应于公式2
    carry_gate = 1.0 - transform_gate
    return transform_gate * layer2 + carry_gate * layer1 #对应于公式3

def highway_a(input_layer, units, act_func):
    H = tf.layers.dense(input_layer, units, act_func)
    T = tf.layers.dense(input_layer, units, tf.nn.sigmoid, bias_initializer=tf.constant_initializer(-1.0))
    return H*T + input_layer*(1-T)

def compute_r(inlayer,head_r,tail_r,dimension):
    head_l=tf.transpose(tf.constant(head_r,dtype=tf.float32))  #转置成了（r，e）的tensor
    tail_l=tf.transpose(tf.constant(tail_r,dtype=tf.float32))
    L=tf.matmul(head_l,inlayer)/tf.expand_dims(tf.reduce_sum(head_l,axis=-1),-1) #第二项r行1列的tensor，每一行都是关系r对应的实体数
    R=tf.matmul(tail_l,inlayer)/tf.expand_dims(tf.reduce_sum(tail_l,axis=-1),-1)#对应于r的平均尾实体表示
    r_embeddings=tf.concat([L,R],axis=0)
    filter = [1, 1, 2, 1]
    r_embeddings = tf.nn.conv2d(r_embeddings, filter, strides=[1, 1, 1, 1])
    # r_embeddings=tf.concat([L,R],axis=-1)  #r行600列的tensor
    w_r = glorot([600, 100]) #生成一个均匀分布，可训练的参数，通过这种初始化有什么好处呢
    r_embeddings_new = tf.matmul(r_embeddings, w_r) #对应于公式6
    return r_embeddings_new #r行100列的2维tensor，每一个r的embedding为100维

def compute_r(inlayer,head_r,tail_r,dimension):
    head_l = tf.transpose(tf.constant(head_r, dtype=tf.float32))  # 转置成了（r，e）的tensor
    tail_l = tf.transpose(tf.constant(tail_r, dtype=tf.float32))

def compute_joint_e(inlayer,r_embeddings,head_r,tail_r):
    head_r=tf.constant(head_r,dtype=tf.float32)
    tail_r=tf.constant(tail_r,dtype=tf.float32)
    L=tf.matmul(head_r,r_embeddings) #e行100列 的2维tensor
    R=tf.matmul(tail_r,r_embeddings)
    ent_embeddings_new=tf.concat([inlayer, L+R],axis=-1)
    return ent_embeddings_new  #e*400的矩阵的tensor


def get_input_layer(e, dimension, lang):
    print('adding the primal input layer...')
    with open(file='data/' + lang + '_en/' + lang + '_vectorList.json', mode='r', encoding='utf-8') as f:
        embedding_list = json.load(f)#列表所有实体向量
        print(len(embedding_list), 'rows,', len(embedding_list[0]), 'columns.')  #打印出多少行多少列
    input_embeddings = tf.convert_to_tensor(embedding_list) #把列表转化成tensor
    ent_embeddings = tf.Variable(input_embeddings)
    return tf.nn.l2_normalize(ent_embeddings, 1) #l2规范化按行


def get_loss(outlayer, ILL, gamma, k, neg_left, neg_right, neg2_left, neg2_right):
    print('getting loss...')
    left = ILL[:, 0] #源语言
    right = ILL[:, 1]#目标语言
    t = len(ILL)
    left_x = tf.nn.embedding_lookup(outlayer, left) #按照left里的序号进行提取，left里的数字是索引
    right_x = tf.nn.embedding_lookup(outlayer, right)
    A = tf.reduce_sum(tf.abs(left_x - right_x), 1) #列求和，括号内的相当于公式4 A是一个一维tensor
    neg_l_x = tf.nn.embedding_lookup(outlayer, neg_left)#现在的neg_left还没有赋予值仅仅是占个位，二维tensor
    neg_r_x = tf.nn.embedding_lookup(outlayer, neg_right)
    B = tf.reduce_sum(tf.abs(neg_l_x - neg_r_x), 1)
    C = - tf.reshape(B, [t, k])#每一对负例的距离，二维tensor每一行都是一个一个正例所对应的全部负例
    D = A + gamma
    L1 = tf.nn.relu(tf.add(C, tf.reshape(D, [t, 1])))
    neg_l_x = tf.nn.embedding_lookup(outlayer, neg2_left)
    neg_r_x = tf.nn.embedding_lookup(outlayer, neg2_right)
    B = tf.reduce_sum(tf.abs(neg_l_x - neg_r_x), 1)
    C = - tf.reshape(B, [t, k])
    L2 = tf.nn.relu(tf.add(C, tf.reshape(D, [t, 1])))
    return (tf.reduce_sum(L1) + tf.reduce_sum(L2)) / (2.0 * k * t) #loss两种负例相结合，L1，L2分别代表什么？


def build(dimension, act_func, gamma, k, lang, e, ILL, KG,attr,ae_dimension):
    tf.reset_default_graph()
    input_layer = get_input_layer(e, dimension, lang) #得到输入实体特征矩阵
    M = get_sparse_tensor(e, KG) #e*e的稀疏矩阵
    head, tail, head_r, tail_r = rfunc(KG, e) #返回两个字典对应于论文中的Hr，Tr集合，，两个矩阵实体和关系邻接矩阵np类型数据
    
    print('calculate preliminary entity representations')
    #两层GCN
    biases=adj_to_bias(M,[input_layer.shape[0]],nhood=1)
    gat1 = attn_head(input_layer,dimension,biases,act_func,in_drop=0.0, coef_drop=0.0)
    output_prel_e = highway(input_layer,gat1,dimension)
    # gcn_layer_1 = add_diag_layer(input_layer, dimension, M, act_func, dropout=0.0)
    # gcn_layer_1 = highway(input_layer,gcn_layer_1,dimension)
    # gcn_layer_2 = add_diag_layer(gcn_layer_1, dimension, M, act_func, dropout=0.0)
    # output_prel_e = highway(gcn_layer_1,gcn_layer_2,dimension)
    print('calculate attribute representations')
    ae_layer = tf.constant(attr)
    ae_hidden = tf.layers.dense(ae_layer, ae_dimension, act_func, kernel_initializer=tf.glorot_uniform_initializer())
    ae_output = highway_a(ae_hidden, ae_dimension, None)

    # fusion
    output_prel_e = tf.concat([output_prel_e, ae_output], 1)
    output_prel_e = tf.nn.l2_normalize(output_prel_e, 1)

    print('calculate relation representations')
    output_r = compute_r(output_prel_e, head_r, tail_r, dimension)

    print('calculate joint entity representations')
    output_joint_e = compute_joint_e(output_prel_e, output_r, head_r, tail_r)
    
    t = len(ILL) #对齐种子的个数
    neg_left = tf.placeholder(tf.int32, [t * k], "neg_left")
    neg_right = tf.placeholder(tf.int32, [t * k], "neg_right")
    neg2_left = tf.placeholder(tf.int32, [t * k], "neg2_left")
    neg2_right = tf.placeholder(tf.int32, [t * k], "neg2_right")
    loss_1 = get_loss(output_prel_e, ILL, gamma, k, neg_left, neg_right, neg2_left, neg2_right)
    loss_2 = get_loss(output_joint_e, ILL, gamma, k, neg_left, neg_right, neg2_left, neg2_right)
    
    return output_prel_e, output_joint_e, output_r, loss_1, loss_2, head, tail


# get negative samples
def get_neg(ILL, output_layer, k):
    neg = []
    t = len(ILL) #对齐实体种子对的其中一个
    ILL_vec = np.array([output_layer[e1] for e1 in ILL]) #训练出的实体向量对齐种子对的其中一个
    print(ILL_vec.shape)
    KG_vec = np.array(output_layer)
    sim = scipy.spatial.distance.cdist(ILL_vec, KG_vec, metric='cityblock') #生成一个len(ILL_vec)hang len(KG_vec)lie的array
    #每一行是ILL向量与kG向量的相似度
    for i in range(t):
        rank = sim[i, :].argsort() #返回数值从小到大的索引值
        neg.append(rank[0:k])#取前k个作为负例

    neg = np.array(neg)
    neg = neg.reshape((t * k,))#一维
    return neg #所有的负例array


def training(output_prel_e, output_joint_e, output_r, loss_1, loss_2, learning_rate, epochs, ILL, e, k, s, test, test_r, head, tail):#head，tail Hr，Tr集合
    train_step_1 = tf.train.AdamOptimizer(learning_rate).minimize(loss_1)
    train_step_2 = tf.train.AdamOptimizer(learning_rate).minimize(loss_2)
    print('initializing...')
    init = tf.global_variables_initializer()
    sess = tf.Session()
    sess.run(init)
    print('running...')
    J = [] #损失列表
    t = len(ILL)
    ILL = np.array(ILL)
    L = np.ones((t, k)) * (ILL[:, 0].reshape((t, 1)))  #t行k列每一行的值都相同，头实体元素，k个相同的头实体元素为1行
    neg_left = L.reshape((t * k,))  #，赋予neg_left值，一维tensor
    L = np.ones((t, k)) * (ILL[:, 1].reshape((t, 1)))
    neg2_right = L.reshape((t * k,))  #（t*K，）
    print('detect coincidence')
    coinc=detect_coinc(test_r, head, tail, ILL)#关系相似性矩阵，这个矩阵中的关系仅仅是关系的对齐关系种子中的关系

    for i in range(epochs):
        if i<s:  # preliminary training
            if i % 50 == 0: #每50代更新一次负例
                out = sess.run(output_prel_e)
                neg2_left = get_neg(ILL[:, 1], out, k)
                print(neg2_left.shape)
                assert 1==0
                neg_right = get_neg(ILL[:, 0], out, k)
                feeddict = {"neg_left:0": neg_left,
                            "neg_right:0": neg_right,
                            "neg2_left:0": neg2_left,
                            "neg2_right:0": neg2_right}

            sess.run(train_step_1, feed_dict=feeddict)

            if i % 10 == 0:
                th, outvec_e, outvec_r = sess.run([loss_1, output_prel_e, output_r], #每10代输出一回向量嵌入用于计算对齐
                                                feed_dict=feeddict)
                J.append(th)
                get_hits(outvec_e, test)
                if i == s-1 or i==0:
                    get_hits_rel(outvec_r, test_r, coinc)
            print('finish step1')

        else:  # joint training
            if i % 50 == 0:
                out = sess.run(output_joint_e)
                neg2_left = get_neg(ILL[:, 1], out, k)
                neg_right = get_neg(ILL[:, 0], out, k)
                feeddict = {"neg_left:0": neg_left,
                            "neg_right:0": neg_right,
                            "neg2_left:0": neg2_left,
                            "neg2_right:0": neg2_right}

            sess.run(train_step_2, feed_dict=feeddict)
            if i % 10 == 0:
                th, outvec_e, outvec_r = sess.run([loss_2, output_joint_e, output_r],
                                                feed_dict=feeddict)
                J.append(th)
                get_hits(outvec_e, test)
                get_hits_rel(outvec_r, test_r, coinc)
        print('%d/%d' % (i + 1, epochs), 'epochs...')

    sess.close()
    return J
