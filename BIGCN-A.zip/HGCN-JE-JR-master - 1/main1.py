import tensorflow as tf
from include.Config import Config
from include.Model import build, training
from include.Test import *
from include.Load import *
# import os
# os.environ["CUDA_VISIBLE_DEVICES"]="-1"

seed = 12306
np.random.seed(seed)
tf.set_random_seed(seed)

'''
Followed the code style of GCN-Align:
https://github.com/1049451037/GCN-Align
'''

if __name__ == '__main__':
    e = len(set(loadfile(Config.e1, 1)) | set(loadfile(Config.e2, 1)))#e表示所有实体的个数

    ILL = loadfile(Config.ill, 2) #对齐实体种子的元组列表，列表中的每一个元组都是一个对齐实体种子对
    illL = len(ILL) #实体种子对的数量
    np.random.shuffle(ILL) #将对齐种子对的顺序打乱
    train = np.array(ILL[:illL // 10 * Config.seed]) #训练集元素类型ndarray
    test = ILL[illL // 10 * Config.seed:]   #测试集也70%
    test_r = loadfile(Config.ill_r, 2) #对齐关系种子列表
    ent2id = get_ent2id([Config.e1, Config.e2])  # attr #entity ：id 字典
    attr = load_attr([Config.a1, Config.a2],e,ent2id, Config.attr_num)
    KG1 = loadfile(Config.kg1, 3) #三元组列表
    KG2 = loadfile(Config.kg2, 3)
    rel = load_relation(e, KG1 + KG2, Config.rel_num)
    #初次训练
    output_prel_e, output_joint_e, output_r, loss_1, loss_2, head, tail = build(Config.dim, Config.act_func,
                                                                                  Config.gamma, Config.k, Config.language[0:2], e, train, KG1 + KG2, attr, Config.ae_dim,rel, Config.rel_dim


                                                                                )
    J = training(output_prel_e, output_joint_e, output_r, loss_1, loss_2, 0.005, Config.epochs, train, e,
                 Config.k, Config.s, test, test_r, head, tail)
    print('loss:', J)
